export const defaultHomePage = "https://start.duckduckgo.com/";
export const defaultUserAgent = window.navigator.userAgent;
